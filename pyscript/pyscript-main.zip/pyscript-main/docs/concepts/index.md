# Concepts

This section contains various topics that are higher-level and useful to know.

```{toctree}
---
maxdepth: 2
glob:
---
what-is-pyscript
governance/*
```
