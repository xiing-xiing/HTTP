from freedom.app import main

print("IN FREEDOM", main)

if __name__ == "__main__":
    main().main_loop()
